import React, { useState } from "react";
import { useLocation, useNavigate, useParams, useSearchParams } from "react-router-dom";
import { handle_edidte_tarefa } from "./TelaTarefas";

const TarefaDetalhes = () =>{
//    const parans = useParams()
const location = useLocation()
const tarefa = location.state||{}
    const navigite = useNavigate()

    const handle_button_click_voltar = () =>{
navigite(-1)
    }

    const [input_tituloTarefa, setInput_tituloTarefa] = useState(tarefa.titulo)
    const handle_input_titulo_tarefa = (campo) =>{
setInput_tituloTarefa(campo.target.value)
    }

const [radio_finalizada, setRadio_finalizada] = useState(tarefa.finalizada)
const  handle_radio_finalizada = (campo) =>{
    setRadio_finalizada(JSON.parse(campo.target.value))
}

const handle_button_click_salvar = () =>{
alert("Tarefa alterada com sucesso. ")
const tarefaEditada = {...tarefa, titulo: input_tituloTarefa, finalizada: radio_finalizada}
handle_edidte_tarefa(tarefaEditada)
navigite(-1)    
}

return(
<>
<div className="box">
    {/*
    <h2 style={{backgroundColor:"aqua"}}>
        Tarefa: {tarefa.titulo}
        </h2>
        <h3>
            Finalizada:  {tarefa.finalizada == tarefa?"sim":"não"}
        </h3>
        */}

<div style={{textAlign:"left"}}>
    <strong>
        Tarefa: 
        </strong>
<input type="text" 
aria-label="título" 
value={input_tituloTarefa} 
onChange={handle_input_titulo_tarefa}
>
</input>
</div>
<br />
<div style={{textAlign:"left"}}>
<trong>
    Finalizada:
</trong>
<label>
    <input type="radio"
    name="finalizada"
    value={true}
    checked={radio_finalizada===true}
    onChange={handle_radio_finalizada}
    aria-label="finalizada sim"
    >
    </input>
    <span>sim</span>
</label>
<label>
<input type="radio"
name="finalizada"
    value={false}
    checked={radio_finalizada===false}
    onChange={handle_radio_finalizada}
    aria-label="finalizada não"
    >
    </input>
    <span>não</span>
</label>
</div>
<br /> <br />
<button 
onClick={handle_button_click_salvar}
>
    Salvar
    </button>
        <button 
        onClick={handle_button_click_voltar}
        >
            voltar
            </button>
</div>
</>
)
}
export default TarefaDetalhes;