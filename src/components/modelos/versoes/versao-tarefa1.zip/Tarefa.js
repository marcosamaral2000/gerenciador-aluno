import React from "react";
import "./Tarefa.css";
import { AiOutlinePlus } from "react-icons/ai";
import { CgClose } from "react-icons/cg";


const Tarefa =  (props) =>{
    return(
        <div className="tarefa-box"
        style={props.tarefa.finalizada?{borderLeft:"6px solid green"}:{borderLeft: "6px solid red"}}
        tabIndex={2}
        >
            <h1 tabIndex={1}
            onClick={() => {props.handle_update_tarefa(props.tarefa.id)}}
                     aria-label={props.tarefa.titulo+ (props.tarefa.finalizada?"Tarefa finalizada.":"Tarefa não finalizada.")}
            >
                {props.tarefa.titulo}
            </h1>
            <div className="grid-botoes">
                <button
                aria-label="detalhes" 
                className="botao-grid" 
                tabIndex={2} 
                onClick={() => {props.handle_detalhe_tarefa(props.tarefa.id)}}
                >
                    <AiOutlinePlus/>
                </button>
<button aria-label="excluir" className="botao-grid" tabIndex={2} onClick={() =>{props.handle_delete_tarefa(props.tarefa.id)}}>
    <CgClose />
    </button>
            </div>
        </div>
    )
}
export default Tarefa;
