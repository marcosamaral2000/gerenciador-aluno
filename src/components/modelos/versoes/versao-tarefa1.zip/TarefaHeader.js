import React from "react";

const TarefaHeader = () =>{
    return( 
    <div style={{textAlign:"center"}}>
<h1>minhas tarefas</h1>
    </div>
    )
}
export default TarefaHeader;