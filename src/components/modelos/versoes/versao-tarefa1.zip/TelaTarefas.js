import React, { useEffect, useState } from "react";
import "./Tarefa.css";
import Tarefa from "./Tarefa";
import FormCadTarefa from "./FormCadTarefa";
import TarefaHeader from "./TarefaHeader";
import { useNavigate } from "react-router-dom";

const TelaTarefas = () =>{

/*
const [listaTarefas, setListaTarefas] = useState([
    {
        id: 1,
        titulo: "Estudar Javascript",
        finalizada: true
    },
    {
        id: 2,
        titulo: "Revisar Conteúdo",
        finalizada: false
    }
]);
*/

const [listaTarefas, setListaTarefas] = useState(() =>{
    const listaTarefas_storage = localStorage.getItem("listaTarefas")
    return listaTarefas_storage?JSON.parse(listaTarefas_storage):[]
})
//Atualizar o storage sempre que a lista mudar
useEffect(() =>{
localStorage.setItem("listaTarefas", JSON.stringify(listaTarefas))
},[listaTarefas])

const handle_add_tarefa = (titulo_tarefa) =>{
    const novaListaTarefas = [... listaTarefas, 
        {
            id: Math.random(100),
            titulo: titulo_tarefa,
            finalizada: false
        }
    ]
    setListaTarefas(novaListaTarefas)
    }
    
const handle_update_tarefa = (id_tarefa) =>{
    const novaListaTarefa = listaTarefas.map(tarefa => {
        if(tarefa.id === id_tarefa){
            //alert(tarefa.titulo + "Tarefa finalizada. " + (tarefa.finalizada?"sim":"não") )
return{... tarefa, finalizada: !tarefa.finalizada}
        }else{
            return tarefa
        }
    })
    setListaTarefas(novaListaTarefa)
}

const handle_delete_tarefa = (id_tarefa) =>{
const novaListaTarefa = listaTarefas.filter(tarefa =>tarefa.id !== id_tarefa)
setListaTarefas(novaListaTarefa)
alert("Tarefa excluída com sucesso. ")
}

const navigate = useNavigate()
const handle_detalhe_tarefa = (id_tarefa) =>{
const tarefa  = get_Tarefa(id_tarefa)
navigate("/tarefa", {state:tarefa})
}

const get_Tarefa = (id_tarefa) =>{
const tarefa = listaTarefas.filter(tarefa => tarefa.id === id_tarefa)
return tarefa[0]
}

return(
    <>
           <TarefaHeader></TarefaHeader> 
    <div className="box">
        <FormCadTarefa handle_add_tarefa={handle_add_tarefa}></FormCadTarefa>
        {
            listaTarefas.length==0?(<p>Nenhuma tarefa cadastrada.</p>):
        listaTarefas.map(tarefa => 
        <Tarefa tarefa={tarefa} 
        handle_update_tarefa={handle_update_tarefa}
        handle_delete_tarefa={handle_delete_tarefa}
        handle_detalhe_tarefa = {handle_detalhe_tarefa}
        >
        </Tarefa>)}
    </div>
    </>
)
}

export const handle_edidte_tarefa = (tarefa_editada) =>{
var listaTarefaStorege = localStorage.getItem("listaTarefas")
listaTarefaStorege = JSON.parse(listaTarefaStorege)
const novaListaTarefa = listaTarefaStorege.map(tarefa => {
    if(tarefa.id === tarefa_editada.id){
        return tarefa_editada
    }else{
        return tarefa
    }
})
localStorage.setItem("listaTarefas", JSON.stringify(novaListaTarefa))
}
export default TelaTarefas;